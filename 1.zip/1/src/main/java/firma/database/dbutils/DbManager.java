package firma.database.dbutils;

import java.sql.*;

/**
 * Created by   on 2017-06-08.
 */
/*
public class DbManager {
    private static final String DB_URL = "jdbc:oracle:thin:@localhost:1521:";
    private static final String USER = "SYSTEM";
    private static final String PASS = "oracle";

    private static Connection createConnection() {
        Connection connection = null;
        try {
            connection = DriverManager.getConnection(DB_URL,USER,PASS);
        }
        catch (SQLException e){
            System.out.println("Connection to DataBase failed ! Check output consloe");
        }
        return connection;
    }
}
*/