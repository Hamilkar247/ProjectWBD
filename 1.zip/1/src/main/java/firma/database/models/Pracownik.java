package firma.database.models;

/**
 * Created by   on 2017-06-08.
 */
public class Pracownik {
}
